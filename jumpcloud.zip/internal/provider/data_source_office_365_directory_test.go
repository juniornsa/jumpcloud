package provider

import (
	"testing"
)

func Test_dataSourceJumpCloudOffice365Directory(t *testing.T) {
	//resource.ParallelTest(t, resource.TestCase{
	//	PreCheck: func() {},
	//	ProviderFactories: providerFactories,
	//	Steps: []resource.TestStep{
	//		{
	//			Config: fmt.Sprintf(`data "jumpcloud_office365_directory" "test" {
	//			}`),
	//
	//			Check: resource.ComposeTestCheckFunc(
	//				resource.TestCheckResourceAttr("jumpcloud_office365_directory.test", "name", "test_name"),
	//			),
	//		},
	//	},
	//})
}
