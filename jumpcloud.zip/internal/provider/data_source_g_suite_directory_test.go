package provider

import (
	"testing"
)

func Test_dataSourceJumpCloudGSuiteDirectory(t *testing.T) {
	//resource.ParallelTest(t, resource.TestCase{
	//	PreCheck: func() {},
	//	ProviderFactories: providerFactories,
	//	Steps: []resource.TestStep{
	//		{
	//			Config: fmt.Sprintf(`data "jumpcloud_gsuite_directory" "test" {
	//			}`),
	//
	//			Check: resource.ComposeTestCheckFunc(
	//			),
	//		},
	//	},
	//})
}
